 <footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="https://candidhomes.in">Candid Homes</a>.</strong>
    All rights reserved. <a href="https://acuteinfos.in">Acute Info Solutions</a>
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 4.1.0
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 new-->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->

<!-- overlayScrollbars new-->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>

<!-- Select2 -->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/select2/js/select2.full.min.js"></script>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/adminz/plugins/lightbox2/dist/js/lightbox.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/adminz/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- Ekko Lightbox -->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/ekko-lightbox/ekko-lightbox.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/adminz/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/adminz/dist/js/demo.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/adminz/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!--<script src="https://code.jquery.com/jquery-3.5.1.js"></script>-->
<!-- Page specific script-->
<script>
  $(function () {
          $("#examplel2").DataTable({
    
      "responsive": true, "lengthChange": false, "autoWidth": false,
        "scrollX": true,
        responsivePriority: 1,
    /*  "scrollY": 200,*/
        
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      
    $("#example1").DataTable({
            //"paging": false,
            
           
          dom:'lBfrtip',
          //buttons: ['excel', 'csv', 'pdf', 'copy'],
         "lengthMenu": [50,100,500,1000,2000,5000,10000,50000,100000],
         //"order":[],
         //"sScrollX": "100%",
         //"scrollCollapse": true,
           
      "responsive": true, "lengthChange": false, "autoWidth": false,
          // "scrollX": true,
        //responsivePriority: 1,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis",'pageLength']
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

    $("#exampleshaj").DataTable({
            //"paging": false,
           
          dom:'lBfrtip',
          //buttons: ['excel', 'csv', 'pdf', 'copy'],
         "lengthMenu": [50,100,500,1000,2000,5000,10000,50000,100000],
         //"order":[],
         //"sScrollX": "100%",
         //"scrollCollapse": true,
           "fixedColumns": true,
      "responsive": false, "lengthChange": false, "autoWidth": false,
           //"scrollX": true,
        "responsivePriority": 2,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis",'pageLength']
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

 $("#examplepurto").DataTable({
//autoFill: true,
     dom:'lBfrtip',
         // buttons: ['excel', 'csv', 'pdf', 'copy'],
         "lengthMenu": [50,100,500,1000,2000,5000,10000,50000,100000],
         //"order":[],
         //"sScrollX": "100%",
         //"scrollCollapse": true,
      
         "footerCallback": function ( row, data, start, end, display ) {
         var api = this.api(), data;
         // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
         // Total over all pages
            var amttotal = api
                .column( 9 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
         var netamttotal = api
                .column( 10 )
                .data()
                .reduce( function (a, b) {
                    return intVal(a) + intVal(b);
                }, 0 );
          //$( api.column( 0 ).footer() ).html('total');
         $( api.column( 9 ).footer() ).html(amttotal);
         $( api.column( 10 ).footer() ).html(netamttotal);
         //$( api.column( 12 ).footer() ).html(netamttotal);
     },
     "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis",'pageLength']
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

       $("#examplepur").DataTable({
           "autoFill": true,
      "responsive": false, "lengthChange": false, "autoWidth": true,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

      $("#example8").DataTable({
          searching: false,
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      
    $("#example3").DataTable({
    
      "responsive": true, "lengthChange": false, "autoWidth": false,
        "scrollX": true,
        responsivePriority: 1,
    /*  "scrollY": 200,*/
        
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
      

      
         $('#examplel1').DataTable( {
        initComplete: function () {
            this.api().columns([1, 2]).every( function () {
                var column = this;
                //$('#example1 thead tr').clone(true).appendTo( '#example1 thead' );
                //var select ="";
                //alert(column.index);
                if(column.index()==2){
                 var select = $('<select id="type" name="type" style="width: 100%;" class="select2 form-control"><option value="">Select Type</option></select>')
                .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                        
                    } );
                }
                else if(column.index()==1){
                     var select = $('<select id="district" name="district" style="width: 100%;" class="select2 form-control"><option value="">Select District</option></select>')
                .appendTo( $(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = $.fn.dataTable.util.escapeRegex(
                            $(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
                }
                
                else{
                    
                }
                  $('.select2').select2();
                
                  //$('.select3').select2();
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        },
             drawCallback: function() {
     $('.select2').select2();
  },
   "responsive": true, "lengthChange": false, "autoWidth": false,
        //"scrollX": true,
        //responsivePriority: 1, 
        //orderCellsTop: true,
        //fixedHeader: true,
    /*  "scrollY": 200,*/
        
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
        
    }).buttons().container().appendTo('#examplel1_wrapper .col-md-6:eq(0)');
$('.select2').select2();
     
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
      $('.dataTables_length').addClass('bs-select');
});
     $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    })

    /*$(document).ready(function () {
$('#example1').DataTable({
"scrollX": true,
"scrollY": 200,
});
$('.dataTables_length').addClass('bs-select');
});*/
   
</script>
<script>
 $(document).on('click', '[data-toggle="lightbox"]', function(event) {
      event.preventDefault();
      $(this).ekkoLightbox({
        alwaysShowClose: true
      });
    });

</script>


<script type="text/javascript" >

 
         $(document).ready(function(){
             //$.noConflict();
             //show_product();
             //$('#dom-jqry').DataTable();
         //call function show all product
         
       
            
          var urls="<?php echo base_url(); ?>administrators/products/edit/";
        //function show all product
        function show_product(){
            $.ajax({
                type  : 'ajax',
                //url   : '<?php //echo site_url('product/product_data')?>',
                url  : "<?php echo base_url('administrators/advertisements/product_data')?>",
                async : true,
                dataType : 'json',
                success : function(data){
                    var html = '';
                    var i;
                    for(i=0; i<data.length; i++){
                        urls="<?php echo base_url(); ?>administrators/products/edit/"+data[i].id;
                        var imgurls="<?php echo site_url();?>assets/images/products/"+data[i].image;
                        html += '<tr>'+
                                '<td>'+(i+1)+'</td>'+
                             '<td> <a href="'+imgurls+'"  data-toggle="lightbox" data-title="'+data[i].name+'" alt=""> <img width="30px;" src="'+imgurls+'"  class="img-fluid mb-2"  alt= alt="black sample">'+'</a></td>'+
                             '<td><a href="'+urls+'">'+data[i].name+'</a></td>'+
                                '<td>'+data[i].quantity+'</td>'+
                                '<td>'+data[i].short_description+'</td>'+
                                '<td>'+'&#8377;'+data[i].price+'</td>'+
                                '<td>'+data[i].prid+'</td>'+
                                '<td>'+
                                    '<a href="javascript:void(0);" class="btn btn-info btn-sm editRecord" data-product_id="'+data[i].id+'" data-product_prid="'+data[i].prid+'">Edit</a>'+' '+
                                   
                                '</td>'+
                                '</tr>';
                    }
                    $('#show_data').html(html);
                }
 
            });
        }
             
             show_product();
      
     $('#show_data').on('click','.editRecord',function(){
        // alert('hi');
            var product_id = $(this).data('product_id');
            var product_prid = $(this).data('product_prid');
         $('#statusMsg').html("");
            //$("#modalForm").modal("show");
            $("#modal-default").modal("show");
            $('[name="prstatus"]').val(product_prid);
            $('[name="product_code_edit"]').val(product_id);
            //$('[name="price_edit"]').val(price);
        });

     //update record to database
         $('#btn_update').on('click',function(){
             
            var product_id = $('#product_code_edit').val();
            var product_prid = $('#prstatus').val();
            //alert('clicked'+product_id+product_prid);
            $.ajax({
                type : "POST",
                url  : "<?php echo base_url('administrators/advertisements/update_prior')?>",
                dataType : "JSON",
                data : {product_id:product_id , product_prid:product_prid},
                success: function(data){
                    $('[name="product_code_edit"]').val("");
                    $('[name="prstatus"]').val("");
                    $('#statusMsg').html("Updated Successfully");
                    //$('#modalForm').modal('hide');
                    //$('#modal-default').modal('hide');
            setTimeout(function(){
    $('#modal-default').modal('hide')
}, 2000);
                    show_product();
                }
            });
            //return false;
        });
        }); 
</script>
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2();
          
  });
</script>
<script>
  $(document).ready(function() {
    $('.product-image-thumb').on('click', function () {
      var $image_element = $(this).find('img')
      $('.product-image').prop('src', $image_element.attr('src'))
      $('.product-image-thumb.active').removeClass('active')
      $(this).addClass('active')
    })
  });
</script>
<script>
$(document).ready(function(){
    if($('#mupdate_purcbill').val()!=null)   {

        $(".updsalespay").submit(function(e){
        e.preventDefault();
         var theForm = $(this);
        //alert('hiiiii');
        // if(theForm.image.size>=2*1024*1024) {
        //         alert("JPG images of maximum 2MB");
        //         $("#form-id").get(0).reset(); //the tricky part is to "empty" the input file here I reset the form.
        //         return;
        //     }
        //     else
        //     {
        //         alert("nothing found");
        //     }

        
        //var dataString = $("#basicform*").serialize();
        //var dataString = $(theForm).serialize();
        var dataString = new FormData(this);
        //alert(dataString);
        //return false;
        var amk="http://127.0.0.1/candid/crm/administrator/update-purcbill/";
        //alert(dataString);
        $.ajax({
                type : "POST",
                url  : amk, 
                dataType: "JSON",    
                //data: dataString,

                data:new FormData(this),
                processData:false,
                contentType:false,
                cache:false,
                async:false,
                success: function(response){
                     //alert(response['success']);
                     if(response['success']===true)
                     {

                        $('.statusMsg').html("Updated Successfully..");
                        setTimeout(function(){$('.updsalespayfm').modal('hide')}, 8000);
                        //location.reload();

                     }
                     else
                     {
                        $('.statusMsg').html("Error Occured. Please try later.");
                        setTimeout(function(){$('.updsalespayfm').modal('hide')}, 8000);
                    //  //location.reload();
                     }
                    //location.reload();
                    setTimeout(location. reload. bind(location), 1000);
                }

                }); 
        return false;
    });

    }

});
</script>
</body>
</html>  

