<?php
 if ($this->session -> userdata('email') == "" && $this->session -> userdata('login') != true && $this->session -> userdata('role_id') != 1) {
      redirect('administrator/index');
    }
 ?>
 <!-- Main Sidebar Container 
 400 12px/1.6 'Open Sans', Verdana, Helvetica, sans-serif;
-->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
   <!-- <a href="index3.html" class="brand-link">
      <img src="<?php //echo base_url(); ?>assets/adminz/dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
        <span class="brand-text font-weight-light">AcuteFresh </span>  
    </a>-->
<a href="<?php echo base_url(); ?>administrator/dashboard"  class="brand-link bg-white">
                 <?php if($this->session->userdata('image') != ""){ ?>
                        <img src="<?php echo base_url(); ?>assets/images/<?php echo $this->session->userdata('site_logo'); ?>" alt="Site Logo" class="img-fluid" style="opacity: .8">
                    <?php }else{ ?>
                          <img class="img-fluid" src="<?php echo base_url(); ?>assets/images/logo-small.png" alt="CandidLogo" class="img-fluid" style="width: auto; height: 50px; align-content: center" />
                    <?php } ?>
     <!--               <br/>
                       <span class="brand-text font-weight-light">AcuteFresh </span>  -->
                       CandidHomes
                </a>
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo base_url(); ?>assets/images/user.png" class="img-circle elevation-2" alt="User Image">
          
          
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php if($this->session->userdata('name') != ""){ echo $this->session->userdata('name');}?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2" style="margin-bottom: 30px;">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="<?php echo base_url('administrator/dashboard'); ?>" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            
          </li>

        <!-- Marketing-->  

        <li class="<?php if($this->uri->segment(2)=="create-leads" || $this->uri->segment(2)=="leads" || $this->uri->segment(2)=="view_leads" || $this->uri->segment(2)=="process_leads" || $this->uri->segment(2)=="edit_leads" || $this->uri->segment(2)=="meeting-tracker-add"  || $this->uri->segment(2)=="meetingstracker"  || $this->uri->segment(2)=="create-orders" ||  $this->uri->segment(2)=="orders" || $this->uri->segment(2)=="edit_orders" || $this->uri->segment(2)=="view_orders" || $this->uri->segment(2)=="create-assign" ||  $this->uri->segment(2)=="assign" || $this->uri->segment(2)=="edit_assign"  || $this->uri->segment(2)=="create-workstatus" ||  $this->uri->segment(2)=="workstatus" || $this->uri->segment(2)=="edit_workstatus" || $this->uri->segment(2)=="create-services" ||  $this->uri->segment(2)=="leads-services" || $this->uri->segment(2)=="view_services" || $this->uri->segment(2)=="edit-services" || $this->uri->segment(2)=="create-complaints" ||  $this->uri->segment(2)=="leads-complaints" || $this->uri->segment(2)=="view_complaints" || $this->uri->segment(2)=="edit-complaints"){echo "nav-item menu-open";} else{echo "nav-item";}?>">
            <a href="#" class="nav-link">
             <i class="nav-icon fas fa-edit  text-warning"></i>
              <p>
                Marketing
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right">3</span>
              </p>
            </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/leads" class="<?php if($this->uri->segment(2)=="create-leads" ||  $this->uri->segment(2)=="leads" || $this->uri->segment(2)=="view_leads" || $this->uri->segment(2)=="process_leads" || $this->uri->segment(2)=="edit_leads"|| $this->uri->segment(2)=="meeting-tracker-add"  || $this->uri->segment(2)=="meetingstracker"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                  <i class="ion ion-bag  nav-icon text-warning"></i>
                  
                  <p>Leads Processing</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/leads-services" class="<?php if($this->uri->segment(2)=="leads-services" ||  $this->uri->segment(2)=="create-services" ||  $this->uri->segment(2)=="edit-services"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                  <i class="ion ion-settings  nav-icon text-warning"></i>
                  
                  <p>Services</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/leads-complaints" class="<?php if($this->uri->segment(2)=="leads-complaints" ||  $this->uri->segment(2)=="create-complaints"  || $this->uri->segment(2)=="edit-complaints"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                  <i class="fas fa-times  nav-icon text-warning"></i>
                  
                  <p>Complaints</p>
                </a>
              </li>

            </ul>
        </li>

        <!-- Sales-->  

        <li class="<?php if($this->uri->segment(2)=="view-leadquotes" ||  $this->uri->segment(2)=="orders" || $this->uri->segment(2)=="view-quotes-process" || $this->uri->segment(2)=="edited-quotes-process" || $this->uri->segment(2)=="add-quotes-process" || $this->uri->segment(2)=="edit_orders"){echo "nav-item menu-open";} else{echo "nav-item";}?>">
            <a href="#" class="nav-link">
             <i class="nav-icon icofont icofont-tasks-alt text-success"></i>
              <p>
                Sales
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right">1</span>
              </p>
            </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/view-leadquotes" class="<?php if($this->uri->segment(2)=="view-leadquotes" ||  $this->uri->segment(2)=="view-quotes-process" ||  $this->uri->segment(2)=="edited-quotes-process" || $this->uri->segment(2)=="add-quotes-process"  ){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="fas fa-clipboard-list  nav-icon text-success"></i>
                  
                  <p>Sales Order</p>
                </a>
              </li>
             
            </ul>
        </li>

         <!-- Purchase Orders-->

        <li class="<?php if($this->uri->segment(2)=="showroomrfp" || $this->uri->segment(2)=="showroomrfp-process" || $this->uri->segment(2)=="showroomrfpw" || $this->uri->segment(2)=="edit_showroomrfpw"){echo "nav-item menu-open";} else{echo "nav-item";}?>">
            <a href="#" class="nav-link">
              <i class="fas fa-shipping-fast  nav-icon text-orange"></i>
             
              <p>
                Purchase Orders
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right">2</span>
              </p>
            </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/showroomrfp" class="<?php if($this->uri->segment(2)=="showroomrfp" || $this->uri->segment(2)=="showroomrfp-process"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="fas fa-cart-arrow-down  nav-icon text-orange"></i>
                  
                  <p>Finished Goods</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/showroomrfpw" class="<?php if($this->uri->segment(2)=="showroomrfpw" || $this->uri->segment(2)=="edit_showroomrfpw"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="fas fa-cart-plus  nav-icon text-orange"></i>
                  <p>Raw Materials</p>
                </a>
              </li>
           
             
            </ul>
        </li>

         <!-- accounting-->


        <li class="<?php if($this->uri->segment(2)=="purchase" ||  $this->uri->segment(2)=="purchase-invoice" || $this->uri->segment(2)=="sales-invoice" || $this->uri->segment(2)=="viewsales-payments" || $this->uri->segment(2)=="viewpurchase-payments"){echo "nav-item menu-open";} else{echo "nav-item";}?>">
            <a href="#" class="nav-link">
            <i class="nav-icon icofont icofont-tasks text-info"></i>
              <p>
                Accounting
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right">3</span>
              </p>
            </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/purchase" class="<?php if($this->uri->segment(2)=="purchase"  || $this->uri->segment(2)=="viewpurchase-payments"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="fas fa-cart-plus nav-icon text-info"></i>
                  
                  <p>Purchases</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/purchase-invoice" class="<?php if($this->uri->segment(2)=="purchase-invoice"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="fas fa-file nav-icon text-info"></i>
                  
                  <p>Purchases Invoices</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/sales-invoice" class="<?php if($this->uri->segment(2)=="sales-invoice" || $this->uri->segment(2)=="viewsales-payments"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="fas fa-expand-arrows-alt nav-icon text-info"></i>
                  
                  <p>Sales Invoices</p>
                </a>
              </li>
                     
            </ul>
        </li>


         <!-- inventory-->

        <li class="<?php if($this->uri->segment(2)=="create-customers" ||  $this->uri->segment(2)=="customers" || $this->uri->segment(2)=="edit_customers" || $this->uri->segment(2)=="user-address" || $this->uri->segment(2)=="view-address" ||  $this->uri->segment(3)=="view-profile" || $this->uri->segment(2)=="create-staffs" || $this->uri->segment(2)=="staffs" || $this->uri->segment(2)=="edit_staffs" || $this->uri->segment(2)=="vendors" || $this->uri->segment(2)=="edit_vendors" || $this->uri->segment(2)=="create-vendors" || $this->uri->segment(2)=="categories" || $this->uri->segment(2)=="products" || $this->uri->segment(2)=="edit_products" || $this->uri->segment(2)=="create-products" ||  $this->uri->segment(2)=="create-subcategories" ||  $this->uri->segment(2)=="subcategories" || $this->uri->segment(2)=="edit_subcategories" ){echo "nav-item menu-open";} else{echo "nav-item";}?>">
            <a href="#" class="nav-link">
             <i class="nav-icon fas fa-search text-warning"></i>
              <p>
                Inventory
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right">7</span>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo base_url('administrator/customers'); ?>"  class="<?php if($this->uri->segment(2)=="customers" || $this->uri->segment(2)=="edit_customers" || $this->uri->segment(2)=="create-customers"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="nav-icon fas fa-users  text-warning"></i>
                  <p>Customers</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/user-address" class="<?php if($this->uri->segment(2)=="user-address" || $this->uri->segment(2)=="view-address" ||  $this->uri->segment(3)=="view-profile"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="fas fa-address-book nav-icon text-warning"></i>
                  <p>Address</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/staffs" class="<?php if($this->uri->segment(2)=="create-staffs" || $this->uri->segment(2)=="staffs" || $this->uri->segment(2)=="edit_staffs"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="nav-icon fa fa-user  text-warning"></i>
                  <p>Staffs</p>
                </a>
              </li>

              <li class="nav-item">
                  <a href="<?php echo base_url(); ?>administrator/products" class="<?php if($this->uri->segment(2)=="products" || $this->uri->segment(2)=="edit_products" || $this->uri->segment(2)=="create-products"){echo "nav-link active";} else{echo "nav-link";}?>">
                    <i class="nav-icon fas fa-shopping-cart text-warning"></i>

                    <p>Products</p>
                  </a>
                </li>

                <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/categories" class="<?php if($this->uri->segment(2)=="categories"){echo "nav-link active";} else{echo "nav-link";}?>">
                 
                 <i class="nav-icon icofont icofont-tasks text-warning"></i>
                  
                  <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/subcategories" class="<?php if($this->uri->segment(2)=="subcategories" || $this->uri->segment(2)=="edit_subcategories" || $this->uri->segment(2)=="create-subcategories"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="nav-icon icofont icofont-tasks-alt text-warning"></i>
                  <p>Sub Category</p>
                </a>
              </li>

             
              <li class="nav-item">
                <a href="<?php echo base_url(); ?>administrator/vendors" class="<?php if($this->uri->segment(2)=="vendors" || $this->uri->segment(2)=="edit_vendors" || $this->uri->segment(2)=="create-vendors"){echo "nav-link active";} else{echo "nav-link";}?>">
                  <i class="nav-icon fas fa-users text-warning"></i>
                  <p>Vendors</p>
                </a>
              </li>
           
            </ul>
        </li>


        <!-- feedback-->

        <li class="nav-item">
            <a href="<?php echo base_url('administrator/feedback'); ?>" class="<?php if($this->uri->segment(2)=="feedback"){echo "nav-link active";} else{echo "nav-link";}?>">
              <i class="nav-icon fas fa-envelope  text-red"></i>
              <p>
                Feedback
                <i class="fas fa-angle-right right"></i>
                <span class="badge badge-info right"></span>
              </p>
            </a>
            
        </li>
          
         <!-- menu ends for here-->
     
    
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>